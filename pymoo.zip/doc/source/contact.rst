
Contact
====================================================================

Feel free to contact me if you have any question:

| `Julian Blank <http://julianblank.com>`_  (blankjul [at] egr.msu.edu)
| Michigan State University
| Computational Optimization and Innovation Laboratory (COIN)
| East Lansing, MI 48824, USA


