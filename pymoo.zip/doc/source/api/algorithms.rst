Algorithms
==============================================================================

.. autoclass:: pymoo.algorithms.so_genetic_algorithm.GA
    :noindex:

.. autoclass:: pymoo.algorithms.so_de.DE
    :noindex:

.. autoclass:: pymoo.algorithms.so_pso.PSO
    :noindex:

.. autoclass:: pymoo.algorithms.nsga2.NSGA2
    :noindex:

.. autoclass:: pymoo.algorithms.rnsga2.RNSGA2
    :noindex:

.. autoclass:: pymoo.algorithms.nsga3.NSGA3
    :noindex:

.. autoclass:: pymoo.algorithms.unsga3.UNSGA3
    :noindex:

.. autoclass:: pymoo.algorithms.rnsga3.RNSGA3
    :noindex:

.. autoclass:: pymoo.algorithms.moead.MOEAD
    :noindex:
