API Reference
==============================================================================

.. toctree::
   :maxdepth: 1

   model
   algorithms
   factory
