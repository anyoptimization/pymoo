Factory
==============================================================================

.. py:currentmodule:: pymoo.factory
.. autofunction:: get_algorithm
.. autofunction:: get_sampling
.. autofunction:: get_selection
.. autofunction:: get_crossover
.. autofunction:: get_mutation
.. autofunction:: get_termination