$(document).ready(function() {
    $('table').removeClass('docutils');
    $('table').addClass('my-table pure-table pure-table-bordered');
});

