
Customization
==============================================================================



.. toctree::
    :maxdepth: 1

    binary_problem.ipynb
    discrete_problem.ipynb
    permutation.ipynb
    mixed_variable_problem.ipynb
    custom.ipynb
    initialization.ipynb
    subset_selection.ipynb
