#!/usr/bin/env bash
source ~/anaconda3/etc/profile.d/conda.sh
conda activate base
make html